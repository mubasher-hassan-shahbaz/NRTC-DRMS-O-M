import { getPunjabOverview } from "@/actions/reports";
import { OverviewCards } from "@/components/admin/OverviewCards";
import { AvailabilityChart } from "@/components/admin/AvailabilityChart";
import { DistrictsTable, type DistrictRow } from "@/components/admin/DistrictsTable";
import { overallCameraAvailability } from "@/lib/calculations";
import type { ReportStatus, DailyReport, District } from "@/lib/types";
import { formatDate } from "@/lib/utils";

export default async function AdminOverviewPage() {
  const { districts, todayReports, recentReports } = await getPunjabOverview();

  const todayByDistrict = new Map(todayReports.map((r) => [r.district_id, r as unknown as DailyReport]));
  const submittedToday = todayReports.length;

  const availabilities = todayReports.map((r) => overallCameraAvailability(r as unknown as DailyReport));
  const avgAvailability =
    availabilities.length > 0
      ? availabilities.reduce((a: number, b: number) => a + b, 0) / availabilities.length
      : 0;

  const ofcCutsToday = todayReports.filter((r) => r.ofc_cut === "Yes").length;

  const rows: DistrictRow[] = districts
    .map((d) => {
      const r = todayByDistrict.get((d as District).id);
      return {
        id: d.id,
        name: d.name,
        division: d.division,
        status: (r ? r.status : "PENDING") as ReportStatus | "PENDING",
        availability: r ? overallCameraAvailability(r) : null,
        reportId: r?.id,
      };
    })
    .sort((a, b) => (a.status === "PENDING" ? -1 : 1) - (b.status === "PENDING" ? -1 : 1));

  // Build a 7-day provincial average trend from recentReports.
  const byDay = new Map<string, number[]>();
  for (const r of recentReports as unknown as DailyReport[]) {
    const pct = overallCameraAvailability(r);
    const arr = byDay.get(r.report_date) ?? [];
    arr.push(pct);
    byDay.set(r.report_date, arr);
  }
  const chartData = Array.from(byDay.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-7)
    .map(([date, vals]) => ({
      day: formatDate(date),
      availability: vals.reduce((a, b) => a + b, 0) / vals.length,
    }));

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-lg font-semibold text-ink">Punjab Overview</h1>
        <p className="text-sm text-ink-soft">
          SLA performance summary across all {districts.length} districts — PMU view.
        </p>
      </div>

      <OverviewCards
        totalDistricts={districts.length}
        submittedToday={submittedToday}
        avgAvailability={avgAvailability}
        ofcCutsToday={ofcCutsToday}
      />

      {chartData.length > 0 && <AvailabilityChart data={chartData} />}

      <DistrictsTable rows={rows} />
    </div>
  );
}
