import { createClient } from "@/lib/supabase/server";
import { listReports } from "@/actions/reports";
import { ReportsClient } from "@/components/admin/ReportsClient";
import type { DailyReport } from "@/lib/types";

export default async function AdminReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ open?: string }>;
}) {
  const { open } = await searchParams;
  const supabase = await createClient();
  const { data: districts } = await supabase.from("districts").select("*").order("name");
  const { data: initialReports } = await listReports({});

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-lg font-semibold text-ink">All Reports</h1>
        <p className="text-sm text-ink-soft">Filter, review, and export daily reports across Punjab.</p>
      </div>
      <ReportsClient
        districts={districts ?? []}
        initialReports={(initialReports as DailyReport[]) ?? []}
        openId={open}
      />
    </div>
  );
}
