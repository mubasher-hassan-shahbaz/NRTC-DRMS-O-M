import { login } from "@/actions/auth";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { ShieldCheck, AlertCircle } from "lucide-react";
import { redirect } from "next/navigation";

async function submit(formData: FormData) {
  "use server";
  const result = await login(formData);
  if (result?.error) {
    redirect(`/login?error=${encodeURIComponent(result.error)}`);
  }
}

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;

  return (
    <div className="flex min-h-screen items-center justify-center bg-paper px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-center">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-lg bg-brand text-white">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h1 className="text-lg font-semibold text-ink">NRTC Safe City Portal</h1>
          <p className="mt-1 text-sm text-ink-soft">
            Daily Operations &amp; SLA Reporting — Punjab Safe Cities Authority
          </p>
        </div>

        <form action={submit} className="space-y-4 rounded-lg border border-border bg-card p-6">
          {error && (
            <div className="flex items-start gap-2 rounded-md border border-red/20 bg-red-tint px-3 py-2 text-sm text-red">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" name="email" type="email" required placeholder="engineer@nrtc.gov.pk" />
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input id="password" name="password" type="password" required placeholder="••••••••" />
          </div>
          <Button type="submit" className="w-full">Sign in</Button>
          <p className="pt-1 text-center text-xs text-ink-soft">
            Access is restricted to registered NRTC field engineers and PMU staff.
          </p>
        </form>
      </div>
    </div>
  );
}
