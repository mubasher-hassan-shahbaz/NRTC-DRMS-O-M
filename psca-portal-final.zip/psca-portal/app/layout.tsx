import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NRTC Safe City Reporting Portal",
  description: "Daily Operations & SLA Reporting Portal — Punjab Safe Cities Authority",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
