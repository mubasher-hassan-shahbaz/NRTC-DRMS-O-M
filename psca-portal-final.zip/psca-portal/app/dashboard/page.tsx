import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/actions/auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge, AvailabilityBadge } from "@/components/ui/badge";
import { overallCameraAvailability } from "@/lib/calculations";
import { formatDate } from "@/lib/utils";
import { FilePlus2, FileText } from "lucide-react";

export default async function DistrictDashboardPage() {
  const profile = await getCurrentProfile();
  if (!profile) redirect("/login");

  const supabase = await createClient();
  const today = new Date().toISOString().slice(0, 10);

  const { data: todayReport } = await supabase
    .from("daily_reports")
    .select("id, status")
    .eq("district_id", profile.district_id)
    .eq("report_date", today)
    .maybeSingle();

  const { data: reports } = await supabase
    .from("daily_reports")
    .select("*")
    .eq("district_id", profile.district_id)
    .order("report_date", { ascending: false })
    .limit(30);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-ink">
            {profile.districts?.name} District — Daily Reports
          </h1>
          <p className="text-sm text-ink-soft">
            Log today&apos;s equipment uptime and SLA data for PMU review.
          </p>
        </div>
        <Link href={todayReport ? `/dashboard/report/${todayReport.id}` : "/dashboard/report/new"}>
          <Button>
            <FilePlus2 className="h-4 w-4" />
            {todayReport ? "Continue today's report" : "Start today's report"}
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Report History</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {!reports || reports.length === 0 ? (
            <div className="flex flex-col items-center gap-2 px-5 py-14 text-center">
              <FileText className="h-8 w-8 text-ink-soft/50" />
              <p className="text-sm font-medium text-ink">No reports yet</p>
              <p className="text-sm text-ink-soft">
                Submit your first daily report to see it listed here.
              </p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-ink-soft">
                  <th className="px-5 py-3 font-medium">Date</th>
                  <th className="px-5 py-3 font-medium">Camera Availability</th>
                  <th className="px-5 py-3 font-medium">OFC Cut</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {reports.map((r) => (
                  <tr key={r.id} className="border-b border-border last:border-0 hover:bg-paper">
                    <td className="px-5 py-3 tabular">{formatDate(r.report_date)}</td>
                    <td className="px-5 py-3">
                      <AvailabilityBadge pct={overallCameraAvailability(r)} />
                    </td>
                    <td className="px-5 py-3">
                      {r.ofc_cut === "Yes" ? (
                        <span className="text-red font-medium">Yes</span>
                      ) : (
                        <span className="text-ink-soft">No</span>
                      )}
                    </td>
                    <td className="px-5 py-3">
                      <StatusBadge status={r.status} />
                    </td>
                    <td className="px-5 py-3 text-right">
                      <Link href={`/dashboard/report/${r.id}`} className="text-sm font-medium text-brand hover:underline">
                        View / Edit
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
