import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/actions/auth";
import { WizardContainer } from "@/components/wizard/WizardContainer";

export default async function NewReportPage() {
  const profile = await getCurrentProfile();
  if (!profile) redirect("/login");
  if (!profile.district_id) redirect("/dashboard");

  const today = new Date().toISOString().slice(0, 10);
  const supabase = await createClient();
  const { data: existing } = await supabase
    .from("daily_reports")
    .select("id")
    .eq("district_id", profile.district_id)
    .eq("report_date", today)
    .maybeSingle();

  // A report already exists for today — go edit it instead of creating a duplicate
  // (district_id + report_date is unique in the schema).
  if (existing) redirect(`/dashboard/report/${existing.id}`);

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div>
        <h1 className="text-lg font-semibold text-ink">New Daily Report</h1>
        <p className="text-sm text-ink-soft">{today}</p>
      </div>
      <WizardContainer districtName={profile.districts?.name ?? ""} officerName={profile.name} />
    </div>
  );
}
