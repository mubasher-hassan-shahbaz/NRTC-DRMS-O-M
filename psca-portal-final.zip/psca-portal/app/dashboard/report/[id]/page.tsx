import { redirect, notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/actions/auth";
import { WizardContainer } from "@/components/wizard/WizardContainer";
import { StatusBadge } from "@/components/ui/badge";

export default async function EditReportPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const profile = await getCurrentProfile();
  if (!profile) redirect("/login");

  const supabase = await createClient();
  const { data: report } = await supabase
    .from("daily_reports")
    .select("*")
    .eq("id", id)
    .single();

  if (!report) notFound();
  // RLS also enforces this, but redirect cleanly for a district user viewing
  // a report outside their own district.
  if (profile.role === "DISTRICT_USER" && report.district_id !== profile.district_id) {
    redirect("/dashboard");
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-ink">Daily Report</h1>
          <p className="text-sm text-ink-soft">{report.report_date}</p>
        </div>
        <StatusBadge status={report.status} />
      </div>
      {report.admin_remarks && (
        <div className="rounded-md border border-amber/30 bg-amber-tint px-4 py-3 text-sm text-amber">
          <span className="font-medium">PMU Remarks: </span>
          {report.admin_remarks}
        </div>
      )}
      <WizardContainer
        districtName={profile.districts?.name ?? ""}
        officerName={profile.name}
        initialDraft={report}
        reportStatus={report.status}
      />
    </div>
  );
}
