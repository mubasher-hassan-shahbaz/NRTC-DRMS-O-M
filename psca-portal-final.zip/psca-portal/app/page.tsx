import { redirect } from "next/navigation";
import { getCurrentProfile } from "@/actions/auth";

export default async function RootPage() {
  const profile = await getCurrentProfile();
  if (!profile) redirect("/login");
  if (profile.role === "ADMIN" || profile.role === "AUDITOR") redirect("/admin");
  redirect("/dashboard");
}
