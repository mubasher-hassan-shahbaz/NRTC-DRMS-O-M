import * as React from "react";
import { cn } from "@/lib/utils";
import type { ReportStatus } from "@/lib/types";

const STATUS_STYLES: Record<ReportStatus, string> = {
  DRAFT: "bg-paper text-ink-soft border-border",
  SUBMITTED: "bg-blue-tint text-blue border-blue/20",
  UNDER_REVIEW: "bg-amber-tint text-amber border-amber/20",
  APPROVED: "bg-brand-tint text-brand-dark border-brand/20",
  NEEDS_REVISION: "bg-amber-tint text-amber border-amber/20",
  REJECTED: "bg-red-tint text-red border-red/20",
};

const STATUS_TEXT: Record<ReportStatus, string> = {
  DRAFT: "Draft",
  SUBMITTED: "Submitted",
  UNDER_REVIEW: "Under Review",
  APPROVED: "Approved",
  NEEDS_REVISION: "Needs Revision",
  REJECTED: "Rejected",
};

export function StatusBadge({ status, className }: { status: ReportStatus; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium",
        STATUS_STYLES[status],
        className
      )}
    >
      {STATUS_TEXT[status]}
    </span>
  );
}

export function AvailabilityBadge({ pct, className }: { pct: number; className?: string }) {
  const tone =
    pct >= 95 ? "bg-brand-tint text-brand-dark border-brand/20"
    : pct >= 85 ? "bg-amber-tint text-amber border-amber/20"
    : "bg-red-tint text-red border-red/20";
  return (
    <span className={cn("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold tabular", tone, className)}>
      {pct.toFixed(1)}%
    </span>
  );
}
