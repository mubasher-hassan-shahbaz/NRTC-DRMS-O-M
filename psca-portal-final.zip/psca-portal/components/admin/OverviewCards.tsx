import { Card, CardContent } from "@/components/ui/card";
import { FileCheck2, FileClock, Gauge, Cable } from "lucide-react";
import { cn } from "@/lib/utils";

export function OverviewCards({
  totalDistricts,
  submittedToday,
  avgAvailability,
  ofcCutsToday,
}: {
  totalDistricts: number;
  submittedToday: number;
  avgAvailability: number;
  ofcCutsToday: number;
}) {
  const pending = totalDistricts - submittedToday;
  const availTone =
    avgAvailability >= 95 ? "text-brand" : avgAvailability >= 85 ? "text-amber" : "text-red";

  const cards = [
    {
      label: "Reports Submitted Today",
      value: `${submittedToday} / ${totalDistricts}`,
      icon: FileCheck2,
      tone: "text-brand",
    },
    {
      label: "Districts Pending",
      value: String(pending),
      icon: FileClock,
      tone: pending > 0 ? "text-amber" : "text-brand",
    },
    {
      label: "Provincial Avg. Uptime",
      value: `${avgAvailability.toFixed(1)}%`,
      icon: Gauge,
      tone: availTone,
    },
    {
      label: "OFC Cuts Reported Today",
      value: String(ofcCutsToday),
      icon: Cable,
      tone: ofcCutsToday > 0 ? "text-red" : "text-brand",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map(({ label, value, icon: Icon, tone }) => (
        <Card key={label}>
          <CardContent className="flex items-center justify-between py-5">
            <div>
              <p className="text-xs text-ink-soft">{label}</p>
              <p className={cn("mt-1 text-2xl font-semibold tabular", tone)}>{value}</p>
            </div>
            <Icon className={cn("h-8 w-8 opacity-80", tone)} />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
