"use client";

import { useEffect, useState, useTransition } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { StatusBadge, AvailabilityBadge } from "@/components/ui/badge";
import { ReportModal } from "./ReportModal";
import { listReports } from "@/actions/reports";
import { overallCameraAvailability } from "@/lib/calculations";
import { exportReportsToExcel } from "@/lib/export/excel";
import type { DailyReport, ReportStatus } from "@/lib/types";
import type { District } from "@/lib/types";
import { formatDate } from "@/lib/utils";
import { FileSpreadsheet, Search } from "lucide-react";

const STATUSES: ReportStatus[] = ["SUBMITTED", "UNDER_REVIEW", "APPROVED", "NEEDS_REVISION", "REJECTED", "DRAFT"];

export function ReportsClient({
  districts,
  initialReports,
  openId,
}: {
  districts: District[];
  initialReports: DailyReport[];
  openId?: string;
}) {
  const [reports, setReports] = useState<DailyReport[]>(initialReports);
  const [districtId, setDistrictId] = useState("");
  const [status, setStatus] = useState<ReportStatus | "">("");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<DailyReport | null>(
    initialReports.find((r) => r.id === openId) ?? null
  );
  const [isPending, startTransition] = useTransition();

  function refetch() {
    startTransition(async () => {
      const res = await listReports({
        districtId: districtId || undefined,
        status: (status as ReportStatus) || undefined,
        search: search || undefined,
      });
      setReports((res.data as DailyReport[]) ?? []);
    });
  }

  useEffect(() => {
    refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [districtId, status]);

  const filtered = search
    ? reports.filter(
        (r) =>
          r.districts?.name?.toLowerCase().includes(search.toLowerCase()) ||
          r.profiles?.name?.toLowerCase().includes(search.toLowerCase())
      )
    : reports;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-3">
        <div className="w-full sm:w-48">
          <Select value={districtId} onChange={(e) => setDistrictId(e.target.value)}>
            <option value="">All Districts</option>
            {districts.map((d) => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </Select>
        </div>
        <div className="w-full sm:w-44">
          <Select value={status} onChange={(e) => setStatus(e.target.value as ReportStatus)}>
            <option value="">All Statuses</option>
            {STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
          </Select>
        </div>
        <div className="relative w-full sm:w-56">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-soft" />
          <Input
            className="pl-9"
            placeholder="Search district or officer..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="ml-auto">
          <Button variant="secondary" onClick={() => exportReportsToExcel(filtered)}>
            <FileSpreadsheet className="h-4 w-4" /> Export Excel
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-ink-soft">
                <th className="px-5 py-3 font-medium">District</th>
                <th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Officer</th>
                <th className="px-5 py-3 font-medium">Availability</th>
                <th className="px-5 py-3 font-medium">Status</th>
                <th className="px-5 py-3 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {isPending && (
                <tr><td colSpan={6} className="px-5 py-6 text-center text-ink-soft">Loading…</td></tr>
              )}
              {!isPending && filtered.length === 0 && (
                <tr><td colSpan={6} className="px-5 py-10 text-center text-ink-soft">No reports match these filters.</td></tr>
              )}
              {!isPending && filtered.map((r) => (
                <tr key={r.id} className="border-b border-border last:border-0 hover:bg-paper">
                  <td className="px-5 py-3 font-medium text-ink">{r.districts?.name}</td>
                  <td className="px-5 py-3 tabular">{formatDate(r.report_date)}</td>
                  <td className="px-5 py-3 text-ink-soft">{r.profiles?.name}</td>
                  <td className="px-5 py-3"><AvailabilityBadge pct={overallCameraAvailability(r)} /></td>
                  <td className="px-5 py-3"><StatusBadge status={r.status} /></td>
                  <td className="px-5 py-3 text-right">
                    <button onClick={() => setSelected(r)} className="text-sm font-medium text-brand hover:underline">
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <ReportModal report={selected} onClose={() => setSelected(null)} onReviewed={refetch} />
    </div>
  );
}
