"use client";

import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function AvailabilityChart({
  data,
}: {
  data: { day: string; availability: number }[];
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>7-Day Provincial Availability Trend</CardTitle>
      </CardHeader>
      <CardContent className="h-64 pt-2">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e4e2" vertical={false} />
            <XAxis dataKey="day" tick={{ fontSize: 12, fill: "#4b5468" }} axisLine={false} tickLine={false} />
            <YAxis
              domain={[0, 100]}
              tick={{ fontSize: 12, fill: "#4b5468" }}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v) => `${v}%`}
            />
            <Tooltip
              formatter={(v) => [`${Number(v).toFixed(1)}%`, "Availability"]}
              contentStyle={{ fontSize: 12, borderRadius: 8, borderColor: "#e2e4e2" }}
            />
            <Bar dataKey="availability" fill="#0b6e4f" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
