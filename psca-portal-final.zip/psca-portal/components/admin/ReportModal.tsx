"use client";

import { useState, useTransition } from "react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { StatusBadge, AvailabilityBadge } from "@/components/ui/badge";
import {
  EQUIPMENT_FIELDS,
  EQUIPMENT_LABELS,
  OTHER_EQUIPMENT_FIELDS,
  OTHER_EQUIPMENT_LABELS,
  type DailyReport,
} from "@/lib/types";
import { availabilityPct, overallCameraAvailability } from "@/lib/calculations";
import { reviewReport } from "@/actions/reports";
import { downloadReportPdf } from "@/lib/export/pdf";
import { FileDown } from "lucide-react";

export function ReportModal({
  report,
  onClose,
  onReviewed,
}: {
  report: DailyReport | null;
  onClose: () => void;
  onReviewed: () => void;
}) {
  const [remarks, setRemarks] = useState(report?.admin_remarks ?? "");
  const [isPending, startTransition] = useTransition();

  if (!report) return null;

  function act(status: "APPROVED" | "NEEDS_REVISION" | "REJECTED") {
    startTransition(async () => {
      const res = await reviewReport(report!.id, status, remarks);
      if (!res.error) {
        onReviewed();
        onClose();
      }
    });
  }

  return (
    <Dialog open={!!report} onClose={onClose} title={`${report.districts?.name ?? report.district_id} — ${report.report_date}`} wide>
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <StatusBadge status={report.status} />
            <AvailabilityBadge pct={overallCameraAvailability(report)} />
          </div>
          <Button variant="secondary" size="sm" onClick={() => downloadReportPdf(report)}>
            <FileDown className="h-3.5 w-3.5" /> Export PDF
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
          <div><p className="text-xs text-ink-soft">Officer</p><p className="font-medium">{report.profiles?.name}</p></div>
          <div><p className="text-xs text-ink-soft">Generator</p><p className="font-medium tabular">{report.generator_runtime} hrs</p></div>
          <div><p className="text-xs text-ink-soft">OFC Cut</p><p className={report.ofc_cut === "Yes" ? "font-medium text-red" : "font-medium"}>{report.ofc_cut}</p></div>
          <div><p className="text-xs text-ink-soft">Submitted</p><p className="font-medium tabular">{new Date(report.submitted_at).toLocaleString("en-GB")}</p></div>
        </div>

        <div className="rounded-md border border-border">
          <p className="border-b border-border px-3 py-2 text-xs font-semibold uppercase tracking-wide text-ink-soft">Camera Systems</p>
          {EQUIPMENT_FIELDS.map((f) => (
            <div key={f} className="flex items-center justify-between border-b border-border px-3 py-1.5 text-sm last:border-0">
              <span className="text-ink-soft">{EQUIPMENT_LABELS[f]}</span>
              <span className="tabular">{report[`${f}_online`]}/{report[`${f}_installed`]} ({availabilityPct(report[`${f}_online`], report[`${f}_installed`])}%)</span>
            </div>
          ))}
        </div>

        <div className="rounded-md border border-border">
          <p className="border-b border-border px-3 py-2 text-xs font-semibold uppercase tracking-wide text-ink-soft">Other Equipment</p>
          {OTHER_EQUIPMENT_FIELDS.map((f) => (
            <div key={f} className="flex items-center justify-between border-b border-border px-3 py-1.5 text-sm last:border-0">
              <span className="text-ink-soft">{OTHER_EQUIPMENT_LABELS[f]}</span>
              <span className="tabular">{report[`${f}_online`]}/{report[`${f}_installed`]}</span>
            </div>
          ))}
        </div>

        {report.ofc_cut === "Yes" && (
          <div className="rounded-md border border-red/20 bg-red-tint px-3 py-2 text-sm text-red">
            OFC cut at {report.ofc_location} ({report.ofc_type}). {report.ofc_details}
          </div>
        )}

        <div className="rounded-md border border-border p-3 text-sm">
          <p className="text-xs text-ink-soft">Major Daily Activity</p>
          <p className="mt-1 whitespace-pre-wrap">{report.major_daily_activity}</p>
        </div>

        {(report.rma_details || report.ipnv_offline_reason || report.cee_offline_reason) && (
          <div className="rounded-md border border-border p-3 text-sm space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-soft">Fault Notes</p>
            {report.ipnv_offline_reason && <p><span className="text-ink-soft">IPNV: </span>{report.ipnv_offline_reason}</p>}
            {report.cee_offline_reason && <p><span className="text-ink-soft">CEE: </span>{report.cee_offline_reason}</p>}
            {report.rma_details && <p><span className="text-ink-soft">RMA: </span>{report.rma_details}</p>}
          </div>
        )}

        <div>
          <Label htmlFor="admin_remarks">PMU Admin Remarks</Label>
          <Textarea
            id="admin_remarks"
            rows={3}
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            placeholder="Remarks visible to the district engineer..."
          />
        </div>

        <div className="flex flex-wrap justify-end gap-2 border-t border-border pt-4">
          <Button variant="secondary" disabled={isPending} onClick={() => act("NEEDS_REVISION")}>Request Revision</Button>
          <Button variant="danger" disabled={isPending} onClick={() => act("REJECTED")}>Reject</Button>
          <Button disabled={isPending} onClick={() => act("APPROVED")}>Approve</Button>
        </div>
      </div>
    </Dialog>
  );
}
