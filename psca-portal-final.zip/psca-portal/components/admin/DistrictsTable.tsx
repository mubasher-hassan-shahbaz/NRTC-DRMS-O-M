import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusBadge, AvailabilityBadge } from "@/components/ui/badge";
import type { ReportStatus } from "@/lib/types";

export interface DistrictRow {
  id: string;
  name: string;
  division: string;
  status: ReportStatus | "PENDING";
  availability: number | null;
  reportId?: string;
}

export function DistrictsTable({ rows }: { rows: DistrictRow[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>District Status — Today</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-ink-soft">
              <th className="px-5 py-3 font-medium">District</th>
              <th className="px-5 py-3 font-medium">Division</th>
              <th className="px-5 py-3 font-medium">Availability</th>
              <th className="px-5 py-3 font-medium">Status</th>
              <th className="px-5 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-b border-border last:border-0 hover:bg-paper">
                <td className="px-5 py-3 font-medium text-ink">{r.name}</td>
                <td className="px-5 py-3 text-ink-soft">{r.division}</td>
                <td className="px-5 py-3">
                  {r.availability !== null ? <AvailabilityBadge pct={r.availability} /> : <span className="text-ink-soft">—</span>}
                </td>
                <td className="px-5 py-3">
                  {r.status === "PENDING" ? (
                    <span className="inline-flex items-center rounded-full border border-border bg-paper px-2.5 py-0.5 text-xs font-medium text-ink-soft">
                      Pending
                    </span>
                  ) : (
                    <StatusBadge status={r.status} />
                  )}
                </td>
                <td className="px-5 py-3 text-right">
                  {r.reportId && (
                    <Link href={`/admin/reports?open=${r.reportId}`} className="text-sm font-medium text-brand hover:underline">
                      Inspect
                    </Link>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}
