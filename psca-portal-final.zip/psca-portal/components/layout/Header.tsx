import { logout } from "@/actions/auth";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";

export function Header({
  name,
  designation,
  districtName,
}: {
  name: string;
  designation: string;
  districtName?: string | null;
}) {
  return (
    <header className="flex items-center justify-between border-b border-border bg-card px-5 py-3">
      <div>
        <p className="text-sm font-medium text-ink">{name}</p>
        <p className="text-xs text-ink-soft">
          {designation}
          {districtName ? ` · ${districtName} District` : ""}
        </p>
      </div>
      <form action={logout}>
        <Button type="submit" variant="secondary" size="sm">
          <LogOut className="h-3.5 w-3.5" />
          Sign out
        </Button>
      </form>
    </header>
  );
}
