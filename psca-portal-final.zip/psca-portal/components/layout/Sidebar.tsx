"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  FilePlus2,
  Map,
  ClipboardList,
  ShieldCheck,
} from "lucide-react";

const districtLinks = [
  { href: "/dashboard", label: "My Reports", icon: LayoutDashboard },
  { href: "/dashboard/report/new", label: "New Daily Report", icon: FilePlus2 },
];

const adminLinks = [
  { href: "/admin", label: "Punjab Overview", icon: Map },
  { href: "/admin/reports", label: "All Reports", icon: ClipboardList },
];

export function Sidebar({ role }: { role: "DISTRICT_USER" | "ADMIN" | "AUDITOR" }) {
  const pathname = usePathname();
  const links = role === "DISTRICT_USER" ? districtLinks : adminLinks;

  return (
    <aside className="hidden w-60 shrink-0 border-r border-border bg-card md:flex md:flex-col">
      <div className="flex items-center gap-2 border-b border-border px-5 py-4">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-brand text-white">
          <ShieldCheck className="h-4 w-4" />
        </div>
        <div>
          <p className="text-sm font-semibold leading-tight text-ink">NRTC Safe City</p>
          <p className="text-xs leading-tight text-ink-soft">PSCA Reporting Portal</p>
        </div>
      </div>
      <nav className="flex-1 space-y-1 p-3">
        {links.map(({ href, label, icon: Icon }) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                active
                  ? "bg-brand-tint text-brand-dark"
                  : "text-ink-soft hover:bg-paper hover:text-ink"
              )}
            >
              <Icon className="h-4 w-4" />
              {label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
