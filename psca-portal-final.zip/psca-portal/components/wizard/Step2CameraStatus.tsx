"use client";

import { EquipmentRow } from "./EquipmentRow";
import { EQUIPMENT_FIELDS, EQUIPMENT_LABELS, type ReportDraft } from "@/lib/types";
import { overallCameraAvailability } from "@/lib/calculations";
import { AvailabilityBadge } from "@/components/ui/badge";

export function Step2CameraStatus({
  draft,
  setDraft,
}: {
  draft: ReportDraft;
  setDraft: (patch: Partial<ReportDraft>) => void;
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-ink">Camera Status</h3>
          <p className="text-sm text-ink-soft">
            Availability % and offline count update automatically as you type.
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs text-ink-soft">Overall Camera Availability</p>
          <AvailabilityBadge pct={overallCameraAvailability(draft)} className="mt-1" />
        </div>
      </div>
      <div>
        {EQUIPMENT_FIELDS.map((field) => (
          <EquipmentRow
            key={field}
            label={EQUIPMENT_LABELS[field]}
            installed={draft[`${field}_installed`]}
            online={draft[`${field}_online`]}
            onChange={({ installed, online }) =>
              setDraft({
                [`${field}_installed`]: installed,
                [`${field}_online`]: online,
              } as Partial<ReportDraft>)
            }
          />
        ))}
      </div>
    </div>
  );
}
