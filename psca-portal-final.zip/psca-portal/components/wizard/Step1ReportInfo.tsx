"use client";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { ReportDraft } from "@/lib/types";

export function Step1ReportInfo({
  draft,
  setDraft,
  districtName,
  officerName,
}: {
  draft: ReportDraft;
  setDraft: (patch: Partial<ReportDraft>) => void;
  districtName: string;
  officerName: string;
}) {
  return (
    <div className="space-y-5">
      <div>
        <h3 className="text-sm font-semibold text-ink">Report Info</h3>
        <p className="text-sm text-ink-soft">Confirm the basic details for this daily report.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <Label htmlFor="report_date">Report Date</Label>
          <Input
            id="report_date"
            type="date"
            value={draft.report_date}
            onChange={(e) => setDraft({ report_date: e.target.value })}
            max={new Date().toISOString().slice(0, 10)}
          />
        </div>
        <div>
          <Label>District</Label>
          <Input value={districtName} disabled />
          <p className="mt-1 text-xs text-ink-soft">Locked to your assigned district.</p>
        </div>
        <div>
          <Label>Reporting Officer</Label>
          <Input value={officerName} disabled />
        </div>
      </div>
    </div>
  );
}
