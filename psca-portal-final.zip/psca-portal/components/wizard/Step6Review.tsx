"use client";

import {
  EQUIPMENT_FIELDS,
  EQUIPMENT_LABELS,
  OTHER_EQUIPMENT_FIELDS,
  OTHER_EQUIPMENT_LABELS,
  type ReportDraft,
} from "@/lib/types";
import { availabilityPct, overallCameraAvailability, overallOtherAvailability } from "@/lib/calculations";
import { AvailabilityBadge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils";
import { AlertTriangle } from "lucide-react";

export function Step6Review({
  draft,
  districtName,
  officerName,
}: {
  draft: ReportDraft;
  districtName: string;
  officerName: string;
}) {
  return (
    <div className="space-y-5">
      <div>
        <h3 className="text-sm font-semibold text-ink">Review &amp; Submit</h3>
        <p className="text-sm text-ink-soft">
          Double-check the summary below. Once submitted, the PMU will review this report.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 rounded-md border border-border p-4 text-sm sm:grid-cols-4">
        <div><p className="text-xs text-ink-soft">District</p><p className="font-medium">{districtName}</p></div>
        <div><p className="text-xs text-ink-soft">Date</p><p className="font-medium tabular">{formatDate(draft.report_date)}</p></div>
        <div><p className="text-xs text-ink-soft">Officer</p><p className="font-medium">{officerName}</p></div>
        <div>
          <p className="text-xs text-ink-soft">Camera Availability</p>
          <AvailabilityBadge pct={overallCameraAvailability(draft)} />
        </div>
      </div>

      <div className="rounded-md border border-border">
        <p className="border-b border-border px-4 py-2 text-xs font-semibold uppercase tracking-wide text-ink-soft">
          Camera Systems
        </p>
        {EQUIPMENT_FIELDS.map((f) => (
          <div key={f} className="flex items-center justify-between border-b border-border px-4 py-2 text-sm last:border-0">
            <span className="text-ink-soft">{EQUIPMENT_LABELS[f]}</span>
            <span className="tabular">
              {draft[`${f}_online`]} / {draft[`${f}_installed`]} online — {availabilityPct(draft[`${f}_online`], draft[`${f}_installed`])}%
            </span>
          </div>
        ))}
      </div>

      <div className="rounded-md border border-border">
        <p className="border-b border-border px-4 py-2 text-xs font-semibold uppercase tracking-wide text-ink-soft">
          Other Equipment — {overallOtherAvailability(draft)}% overall
        </p>
        {OTHER_EQUIPMENT_FIELDS.map((f) => (
          <div key={f} className="flex items-center justify-between border-b border-border px-4 py-2 text-sm last:border-0">
            <span className="text-ink-soft">{OTHER_EQUIPMENT_LABELS[f]}</span>
            <span className="tabular">{draft[`${f}_online`]} / {draft[`${f}_installed`]} online</span>
          </div>
        ))}
      </div>

      {draft.ofc_cut === "Yes" && (
        <div className="flex items-start gap-2 rounded-md border border-amber/30 bg-amber-tint px-4 py-3 text-sm text-amber">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>
            OFC cut reported at <strong>{draft.ofc_location || "unspecified location"}</strong> ({draft.ofc_type || "type not specified"}).
          </span>
        </div>
      )}

      <div className="rounded-md border border-border p-4 text-sm">
        <p className="text-xs text-ink-soft">Major Daily Activity</p>
        <p className="mt-1 whitespace-pre-wrap">{draft.major_daily_activity || "—"}</p>
      </div>
    </div>
  );
}
