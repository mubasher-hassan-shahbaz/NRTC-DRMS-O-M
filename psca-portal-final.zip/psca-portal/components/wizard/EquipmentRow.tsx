"use client";

import { Input } from "@/components/ui/input";
import { AvailabilityBadge } from "@/components/ui/badge";
import { availabilityPct, offlineCount } from "@/lib/calculations";

export function EquipmentRow({
  label,
  installed,
  online,
  onChange,
}: {
  label: string;
  installed: number;
  online: number;
  onChange: (next: { installed: number; online: number }) => void;
}) {
  const pct = availabilityPct(online, installed);
  const offline = offlineCount(online, installed);

  return (
    <div className="grid grid-cols-12 items-center gap-3 border-b border-border py-3 last:border-0">
      <div className="col-span-12 text-sm font-medium text-ink sm:col-span-4">{label}</div>
      <div className="col-span-6 sm:col-span-2">
        <Input
          type="number"
          min={0}
          value={installed}
          onChange={(e) => {
            const nextInstalled = Math.max(0, Number(e.target.value) || 0);
            onChange({
              installed: nextInstalled,
              online: Math.min(online, nextInstalled),
            });
          }}
          aria-label={`${label} installed`}
        />
        <p className="mt-1 text-[11px] text-ink-soft">Installed</p>
      </div>
      <div className="col-span-6 sm:col-span-2">
        <Input
          type="number"
          min={0}
          max={installed}
          value={online}
          onChange={(e) =>
            onChange({
              installed,
              online: Math.min(installed, Math.max(0, Number(e.target.value) || 0)),
            })
          }
          aria-label={`${label} online`}
        />
        <p className="mt-1 text-[11px] text-ink-soft">Online</p>
      </div>
      <div className="col-span-6 text-sm text-ink-soft tabular sm:col-span-2">
        {offline} offline
      </div>
      <div className="col-span-6 sm:col-span-2">
        <AvailabilityBadge pct={pct} />
      </div>
    </div>
  );
}
