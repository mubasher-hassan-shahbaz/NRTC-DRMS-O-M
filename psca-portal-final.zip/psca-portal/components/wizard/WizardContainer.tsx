"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { saveDailyReport } from "@/actions/reports";
import { EMPTY_DRAFT, type ReportDraft } from "@/lib/types";
import { Step1ReportInfo } from "./Step1ReportInfo";
import { Step2CameraStatus } from "./Step2CameraStatus";
import { Step3OtherEquipment } from "./Step3OtherEquipment";
import { Step4OfflineIssues } from "./Step4OfflineIssues";
import { Step5Generator } from "./Step5Generator";
import { Step6Review } from "./Step6Review";
import { Check, ChevronLeft, ChevronRight, Loader2 } from "lucide-react";

const STEPS = [
  "Report Info",
  "Camera Status",
  "Other Equipment",
  "Offline / OFC Issues",
  "Generator & Operations",
  "Review & Submit",
];

export function WizardContainer({
  districtName,
  officerName,
  initialDraft,
  reportStatus,
}: {
  districtName: string;
  officerName: string;
  initialDraft?: Partial<ReportDraft>;
  reportStatus?: string;
}) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [draft, setDraftState] = useState<ReportDraft>({ ...EMPTY_DRAFT, ...initialDraft });
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const locked = reportStatus === "APPROVED";

  function setDraft(patch: Partial<ReportDraft>) {
    setDraftState((d) => ({ ...d, ...patch }));
  }

  function submit(status: "DRAFT" | "SUBMITTED") {
    if (status === "SUBMITTED" && !draft.major_daily_activity.trim()) {
      setError("Major Daily Activity likhna zaroori hai submit karne se pehle.");
      setStep(4);
      return;
    }
    setError(null);
    startTransition(async () => {
      const result = await saveDailyReport(draft, status);
      if (result.error) {
        setError(result.error);
        return;
      }
      if (status === "SUBMITTED") {
        router.push("/dashboard");
        router.refresh();
      } else {
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      }
    });
  }

  return (
    <div className="space-y-5">
      <ol className="flex flex-wrap gap-2">
        {STEPS.map((label, i) => (
          <li key={label}>
            <button
              type="button"
              onClick={() => setStep(i)}
              className={cn(
                "flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                i === step
                  ? "border-brand bg-brand-tint text-brand-dark"
                  : i < step
                  ? "border-brand/30 bg-white text-brand"
                  : "border-border bg-white text-ink-soft"
              )}
            >
              <span className={cn(
                "flex h-4 w-4 items-center justify-center rounded-full text-[10px]",
                i <= step ? "bg-brand text-white" : "bg-paper text-ink-soft"
              )}>
                {i < step ? <Check className="h-3 w-3" /> : i + 1}
              </span>
              {label}
            </button>
          </li>
        ))}
      </ol>

      {locked && (
        <div className="rounded-md border border-brand/20 bg-brand-tint px-4 py-3 text-sm text-brand-dark">
          Yeh report PMU se already APPROVED ho chuki hai aur ab edit nahi ki ja sakti.
        </div>
      )}

      {error && (
        <div className="rounded-md border border-red/20 bg-red-tint px-4 py-3 text-sm text-red">
          {error}
        </div>
      )}

      <div className="rounded-lg border border-border bg-card p-5">
        <fieldset disabled={locked} className="contents">
          {step === 0 && <Step1ReportInfo draft={draft} setDraft={setDraft} districtName={districtName} officerName={officerName} />}
          {step === 1 && <Step2CameraStatus draft={draft} setDraft={setDraft} />}
          {step === 2 && <Step3OtherEquipment draft={draft} setDraft={setDraft} />}
          {step === 3 && <Step4OfflineIssues draft={draft} setDraft={setDraft} />}
          {step === 4 && <Step5Generator draft={draft} setDraft={setDraft} />}
          {step === 5 && <Step6Review draft={draft} districtName={districtName} officerName={officerName} />}
        </fieldset>
      </div>

      <div className="flex items-center justify-between">
        <Button variant="secondary" onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0}>
          <ChevronLeft className="h-4 w-4" /> Back
        </Button>

        <div className="flex items-center gap-2">
          {saved && <span className="text-xs text-brand">Draft saved.</span>}
          {!locked && (
            <Button variant="secondary" onClick={() => submit("DRAFT")} disabled={isPending}>
              {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              Save Draft
            </Button>
          )}
          {step < STEPS.length - 1 ? (
            <Button onClick={() => setStep((s) => Math.min(STEPS.length - 1, s + 1))}>
              Next <ChevronRight className="h-4 w-4" />
            </Button>
          ) : (
            !locked && (
              <Button onClick={() => submit("SUBMITTED")} disabled={isPending}>
                {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                Submit Report
              </Button>
            )
          )}
        </div>
      </div>
    </div>
  );
}
