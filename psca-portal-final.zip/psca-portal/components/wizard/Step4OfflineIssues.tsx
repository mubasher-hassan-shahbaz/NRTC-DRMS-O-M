"use client";

import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import type { ReportDraft } from "@/lib/types";

const OFC_TYPES = ["Backbone", "Distribution", "Last Mile", "Patch Cord", "Other"];

export function Step4OfflineIssues({
  draft,
  setDraft,
}: {
  draft: ReportDraft;
  setDraft: (patch: Partial<ReportDraft>) => void;
}) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold text-ink">Offline / Fault / OFC Issues</h3>
        <p className="text-sm text-ink-soft">
          Explain the cause for any offline equipment logged in Steps 2–3, and log fiber cuts.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <Label htmlFor="ipnv_offline_reason">IPNV Offline Reason</Label>
          <Textarea id="ipnv_offline_reason" rows={2} value={draft.ipnv_offline_reason}
            onChange={(e) => setDraft({ ipnv_offline_reason: e.target.value })} />
        </div>
        <div>
          <Label htmlFor="cee_offline_reason">CEE Offline Reason</Label>
          <Textarea id="cee_offline_reason" rows={2} value={draft.cee_offline_reason}
            onChange={(e) => setDraft({ cee_offline_reason: e.target.value })} />
        </div>
        <div>
          <Label htmlFor="ps_offline_reason">Pole Sensor Offline Reason</Label>
          <Textarea id="ps_offline_reason" rows={2} value={draft.ps_offline_reason}
            onChange={(e) => setDraft({ ps_offline_reason: e.target.value })} />
        </div>
        <div>
          <Label htmlFor="dc_offline_reason">Dome Camera Offline Reason</Label>
          <Textarea id="dc_offline_reason" rows={2} value={draft.dc_offline_reason}
            onChange={(e) => setDraft({ dc_offline_reason: e.target.value })} />
        </div>
      </div>

      <div>
        <Label htmlFor="rma_details">RMA / Hardware Dispatch Details</Label>
        <Textarea id="rma_details" rows={2} value={draft.rma_details}
          placeholder="Item, serial number, dispatch date, vendor reference..."
          onChange={(e) => setDraft({ rma_details: e.target.value })} />
      </div>

      <div className="rounded-md border border-border p-4">
        <p className="mb-3 text-sm font-medium text-ink">OFC Cut Incident</p>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label htmlFor="ofc_cut">OFC Cut Today?</Label>
            <Select id="ofc_cut" value={draft.ofc_cut}
              onChange={(e) => setDraft({ ofc_cut: e.target.value as "Yes" | "No" })}>
              <option value="No">No</option>
              <option value="Yes">Yes</option>
            </Select>
          </div>
          {draft.ofc_cut === "Yes" && (
            <>
              <div>
                <Label htmlFor="ofc_location">Cut Location</Label>
                <Input id="ofc_location" value={draft.ofc_location}
                  onChange={(e) => setDraft({ ofc_location: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="ofc_type">Fiber Type</Label>
                <Select id="ofc_type" value={draft.ofc_type}
                  onChange={(e) => setDraft({ ofc_type: e.target.value })}>
                  <option value="">Select type</option>
                  {OFC_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                </Select>
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="ofc_details">Cut Details / Restoration Action</Label>
                <Textarea id="ofc_details" rows={2} value={draft.ofc_details}
                  onChange={(e) => setDraft({ ofc_details: e.target.value })} />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
