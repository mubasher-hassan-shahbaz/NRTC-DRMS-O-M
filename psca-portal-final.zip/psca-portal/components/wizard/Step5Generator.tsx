"use client";

import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import type { ReportDraft } from "@/lib/types";

export function Step5Generator({
  draft,
  setDraft,
}: {
  draft: ReportDraft;
  setDraft: (patch: Partial<ReportDraft>) => void;
}) {
  return (
    <div className="space-y-5">
      <div>
        <h3 className="text-sm font-semibold text-ink">Generator &amp; Daily Operations</h3>
        <p className="text-sm text-ink-soft">Runtime hours and a summary of today&apos;s field activity.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <Label htmlFor="generator_runtime">Generator Runtime (hours)</Label>
          <Input id="generator_runtime" type="number" min={0} max={24} step={0.5}
            value={draft.generator_runtime}
            onChange={(e) => setDraft({ generator_runtime: Number(e.target.value) || 0 })} />
        </div>
      </div>

      <div>
        <Label htmlFor="major_daily_activity">Major Daily Activity *</Label>
        <Textarea id="major_daily_activity" rows={4} required
          placeholder="e.g. Preventive maintenance of DC cluster at Chowk X, replaced faulty PS unit at Y..."
          value={draft.major_daily_activity}
          onChange={(e) => setDraft({ major_daily_activity: e.target.value })} />
      </div>

      <div>
        <Label htmlFor="other_issues">Other Issues (optional)</Label>
        <Textarea id="other_issues" rows={3} value={draft.other_issues}
          onChange={(e) => setDraft({ other_issues: e.target.value })} />
      </div>
    </div>
  );
}
