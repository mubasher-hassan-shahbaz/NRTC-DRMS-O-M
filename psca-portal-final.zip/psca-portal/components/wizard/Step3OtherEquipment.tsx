"use client";

import { EquipmentRow } from "./EquipmentRow";
import { OTHER_EQUIPMENT_FIELDS, OTHER_EQUIPMENT_LABELS, type ReportDraft } from "@/lib/types";
import { overallOtherAvailability } from "@/lib/calculations";
import { AvailabilityBadge } from "@/components/ui/badge";

export function Step3OtherEquipment({
  draft,
  setDraft,
}: {
  draft: ReportDraft;
  setDraft: (patch: Partial<ReportDraft>) => void;
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-ink">Other Equipment</h3>
          <p className="text-sm text-ink-soft">Public WiFi, panic buttons, sensors, and biometrics.</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-ink-soft">Overall Availability</p>
          <AvailabilityBadge pct={overallOtherAvailability(draft)} className="mt-1" />
        </div>
      </div>
      <div>
        {OTHER_EQUIPMENT_FIELDS.map((field) => (
          <EquipmentRow
            key={field}
            label={OTHER_EQUIPMENT_LABELS[field]}
            installed={draft[`${field}_installed`]}
            online={draft[`${field}_online`]}
            onChange={({ installed, online }) =>
              setDraft({
                [`${field}_installed`]: installed,
                [`${field}_online`]: online,
              } as Partial<ReportDraft>)
            }
          />
        ))}
      </div>
    </div>
  );
}
