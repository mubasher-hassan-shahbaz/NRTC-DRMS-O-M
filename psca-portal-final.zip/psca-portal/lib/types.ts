// Core domain types for the PSCA / NRTC Safe City Daily Reporting Portal.
// These mirror supabase/schema.sql exactly — keep both in sync.

export type UserRole = "DISTRICT_USER" | "ADMIN" | "AUDITOR";

export type ReportStatus =
  | "DRAFT"
  | "SUBMITTED"
  | "UNDER_REVIEW"
  | "APPROVED"
  | "NEEDS_REVISION"
  | "REJECTED";

export interface District {
  id: string;
  name: string;
  division: string;
  base_ipnv: number;
  base_cee: number;
  base_dee: number;
  base_wifi: number;
}

export interface Profile {
  id: string;
  name: string;
  nrtc_employee_id: string;
  email: string;
  role: UserRole;
  district_id: string | null;
  designation: string;
  contractor: string;
}

// Every "<x>_installed" / "<x>_online" pair tracked in daily_reports.
export const EQUIPMENT_FIELDS = [
  "ipnv",
  "cee",
  "dee",
  "ps",
  "dc",
  "frnv",
  "mcr_dr",
] as const;
export type EquipmentField = (typeof EQUIPMENT_FIELDS)[number];

export const OTHER_EQUIPMENT_FIELDS = [
  "wifi",
  "panic",
  "environmental",
  "biometric",
] as const;
export type OtherEquipmentField = (typeof OTHER_EQUIPMENT_FIELDS)[number];

export const EQUIPMENT_LABELS: Record<EquipmentField, string> = {
  ipnv: "IP Network Video (IPNV) Cameras",
  cee: "Corridor Entry/Exit (CEE) Cameras",
  dee: "District Entry/Exit (DEE) Cameras",
  ps: "Pole-mounted Sensors (PS)",
  dc: "Dome Cameras (DC)",
  frnv: "Fixed Road Network View (FRNV)",
  mcr_dr: "MCR / DR Link",
};

export const OTHER_EQUIPMENT_LABELS: Record<OtherEquipmentField, string> = {
  wifi: "Public WiFi Access Points",
  panic: "Panic Buttons",
  environmental: "Environmental Sensors",
  biometric: "Biometric Units",
};

export type DailyReport = {
  id: string;
  user_id: string;
  nrtc_employee_id: string;
  contractor: string;
  client_authority: string;
  district_id: string;
  report_date: string;
  status: ReportStatus;
  submitted_at: string;
  updated_at: string;
} & Record<`${EquipmentField}_installed` | `${EquipmentField}_online`, number> &
  Record<`${OtherEquipmentField}_installed` | `${OtherEquipmentField}_online`, number> & {
    ipnv_offline_reason: string | null;
    cee_offline_reason: string | null;
    ps_offline_reason: string | null;
    dc_offline_reason: string | null;
    rma_details: string | null;
    ofc_cut: "Yes" | "No";
    ofc_location: string | null;
    ofc_type: string | null;
    ofc_details: string | null;
    generator_runtime: number;
    major_daily_activity: string;
    other_issues: string | null;
    attachments: unknown[];
    admin_remarks: string | null;
    reviewed_by: string | null;
    reviewed_at: string | null;
    districts?: { name: string; division: string };
    profiles?: { name: string; designation: string };
  };

// Payload shape used by the wizard while a report is being drafted client-side.
export interface ReportDraft {
  report_date: string;
  ipnv_installed: number; ipnv_online: number;
  cee_installed: number; cee_online: number;
  dee_installed: number; dee_online: number;
  ps_installed: number; ps_online: number;
  dc_installed: number; dc_online: number;
  frnv_installed: number; frnv_online: number;
  mcr_dr_installed: number; mcr_dr_online: number;
  wifi_installed: number; wifi_online: number;
  panic_installed: number; panic_online: number;
  environmental_installed: number; environmental_online: number;
  biometric_installed: number; biometric_online: number;
  ipnv_offline_reason: string;
  cee_offline_reason: string;
  ps_offline_reason: string;
  dc_offline_reason: string;
  rma_details: string;
  ofc_cut: "Yes" | "No";
  ofc_location: string;
  ofc_type: string;
  ofc_details: string;
  generator_runtime: number;
  major_daily_activity: string;
  other_issues: string;
}

export const EMPTY_DRAFT: ReportDraft = {
  report_date: new Date().toISOString().slice(0, 10),
  ipnv_installed: 0, ipnv_online: 0,
  cee_installed: 0, cee_online: 0,
  dee_installed: 0, dee_online: 0,
  ps_installed: 0, ps_online: 0,
  dc_installed: 0, dc_online: 0,
  frnv_installed: 0, frnv_online: 0,
  mcr_dr_installed: 0, mcr_dr_online: 0,
  wifi_installed: 0, wifi_online: 0,
  panic_installed: 0, panic_online: 0,
  environmental_installed: 0, environmental_online: 0,
  biometric_installed: 0, biometric_online: 0,
  ipnv_offline_reason: "",
  cee_offline_reason: "",
  ps_offline_reason: "",
  dc_offline_reason: "",
  rma_details: "",
  ofc_cut: "No",
  ofc_location: "",
  ofc_type: "",
  ofc_details: "",
  generator_runtime: 0,
  major_daily_activity: "",
  other_issues: "",
};
