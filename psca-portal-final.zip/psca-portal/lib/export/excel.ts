"use client";

import ExcelJS from "exceljs";
import { EQUIPMENT_FIELDS, EQUIPMENT_LABELS, type DailyReport } from "@/lib/types";
import { overallCameraAvailability } from "@/lib/calculations";

/** Builds and downloads an .xlsx export of the given daily reports, in the browser. */
export async function exportReportsToExcel(reports: DailyReport[], filenameHint = "psca-reports") {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "NRTC Safe City Reporting Portal";
  workbook.created = new Date();

  const sheet = workbook.addWorksheet("Daily Reports");

  sheet.columns = [
    { header: "Date", key: "date", width: 12 },
    { header: "District", key: "district", width: 18 },
    { header: "Officer", key: "officer", width: 22 },
    { header: "Status", key: "status", width: 14 },
    ...EQUIPMENT_FIELDS.flatMap((f) => [
      { header: `${EQUIPMENT_LABELS[f]} Installed`, key: `${f}_i`, width: 14 },
      { header: `${EQUIPMENT_LABELS[f]} Online`, key: `${f}_o`, width: 14 },
    ]),
    { header: "Overall Camera Availability %", key: "avail", width: 16 },
    { header: "OFC Cut", key: "ofc", width: 10 },
    { header: "Generator Runtime (hrs)", key: "gen", width: 14 },
    { header: "Major Daily Activity", key: "activity", width: 40 },
    { header: "Admin Remarks", key: "remarks", width: 30 },
  ];

  sheet.getRow(1).font = { bold: true };
  sheet.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE6F2EC" } };

  for (const r of reports) {
    const row: Record<string, unknown> = {
      date: r.report_date,
      district: r.districts?.name ?? r.district_id,
      officer: r.profiles?.name ?? "",
      status: r.status,
      avail: overallCameraAvailability(r),
      ofc: r.ofc_cut,
      gen: r.generator_runtime,
      activity: r.major_daily_activity,
      remarks: r.admin_remarks ?? "",
    };
    for (const f of EQUIPMENT_FIELDS) {
      row[`${f}_i`] = r[`${f}_installed`];
      row[`${f}_o`] = r[`${f}_online`];
    }
    sheet.addRow(row);
  }

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${filenameHint}-${new Date().toISOString().slice(0, 10)}.xlsx`;
  a.click();
  URL.revokeObjectURL(url);
}
