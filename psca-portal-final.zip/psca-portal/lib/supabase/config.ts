// Public Supabase project config. The anon/publishable key is safe to ship
// in client bundles by design — Supabase's Row Level Security policies
// (see supabase/schema.sql) are what actually control access, not secrecy
// of this key. Baking a default in here means the app deploys correctly
// even with zero environment variables configured on the host; setting the
// NEXT_PUBLIC_SUPABASE_* env vars (e.g. to point at a different project)
// still overrides these defaults.
export const SUPABASE_URL =
  process.env.NEXT_PUBLIC_SUPABASE_URL || "https://emrzmplkvxspcuphzgmi.supabase.co";

export const SUPABASE_ANON_KEY =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVtcnptcGxrdnhzcGN1cGh6Z21pIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk0MTQ5MTQsImV4cCI6MjEwNDk5MDkxNH0.n0UjHKmHAmtpD8q5Guhgu5kW_iVboYas9keymqsYN-Y";
