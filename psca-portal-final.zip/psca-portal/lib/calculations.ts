import {
  EQUIPMENT_FIELDS,
  OTHER_EQUIPMENT_FIELDS,
  type EquipmentField,
  type OtherEquipmentField,
  type ReportDraft,
} from "./types";

/** Availability % = (Online / Installed) * 100, guarding against divide-by-zero. */
export function availabilityPct(online: number, installed: number): number {
  if (!installed || installed <= 0) return 0;
  return Math.round(((online / installed) * 100 + Number.EPSILON) * 10) / 10;
}

export function offlineCount(online: number, installed: number): number {
  return Math.max(0, (installed || 0) - (online || 0));
}

/** Aggregate availability across the 7 core camera categories for a draft/report. */
export function overallCameraAvailability(
  draft: Pick<ReportDraft, `${EquipmentField}_installed` | `${EquipmentField}_online`>
): number {
  let installed = 0;
  let online = 0;
  for (const field of EQUIPMENT_FIELDS) {
    installed += draft[`${field}_installed`] ?? 0;
    online += draft[`${field}_online`] ?? 0;
  }
  return availabilityPct(online, installed);
}

export function overallOtherAvailability(
  draft: Pick<ReportDraft, `${OtherEquipmentField}_installed` | `${OtherEquipmentField}_online`>
): number {
  let installed = 0;
  let online = 0;
  for (const field of OTHER_EQUIPMENT_FIELDS) {
    installed += draft[`${field}_installed`] ?? 0;
    online += draft[`${field}_online`] ?? 0;
  }
  return availabilityPct(online, installed);
}

export function availabilityTone(pct: number): "good" | "warn" | "bad" {
  if (pct >= 95) return "good";
  if (pct >= 85) return "warn";
  return "bad";
}
