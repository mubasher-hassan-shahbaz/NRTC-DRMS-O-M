-- =============================================================================
-- PUNJAB SAFE CITY AUTHORITY (PSCA) - DAILY REPORTING PORTAL
-- PostgreSQL / Supabase Production Database Schema & Row-Level Security (RLS)
-- =============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- -----------------------------------------------------------------------------
-- 1. DISTRICTS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.districts (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    division VARCHAR(100) NOT NULL,
    base_ipnv INTEGER NOT NULL DEFAULT 90,
    base_cee INTEGER NOT NULL DEFAULT 20,
    base_dee INTEGER NOT NULL DEFAULT 10,
    base_wifi INTEGER NOT NULL DEFAULT 15,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Seed 37 Punjab Administrative Districts
INSERT INTO public.districts (id, name, division, base_ipnv, base_cee, base_dee, base_wifi) VALUES
('attock', 'Attock', 'Rawalpindi', 95, 24, 12, 15),
('bahawalnagar', 'Bahawalnagar', 'Bahawalpur', 80, 18, 10, 12),
('bahawalpur', 'Bahawalpur', 'Bahawalpur', 220, 45, 20, 30),
('bhakkar', 'Bhakkar', 'Sargodha', 75, 16, 8, 10),
('chakwal', 'Chakwal', 'Rawalpindi', 90, 20, 10, 15),
('chiniot', 'Chiniot', 'Faisalabad', 85, 18, 10, 12),
('dg_khan', 'Dera Ghazi Khan', 'D.G. Khan', 160, 32, 16, 20),
('faisalabad', 'Faisalabad', 'Faisalabad', 950, 180, 70, 110),
('gujranwala', 'Gujranwala', 'Gujranwala', 680, 130, 55, 85),
('gujrat', 'Gujrat', 'Gujranwala', 210, 42, 20, 28),
('hafizabad', 'Hafizabad', 'Gujranwala', 70, 15, 8, 10),
('jhang', 'Jhang', 'Faisalabad', 140, 28, 14, 18),
('jhelum', 'Jhelum', 'Rawalpindi', 110, 25, 12, 16),
('kasur', 'Kasur', 'Lahore', 190, 38, 18, 25),
('khanewal', 'Khanewal', 'Multan', 120, 24, 12, 15),
('khushab', 'Khushab', 'Sargodha', 75, 16, 8, 10),
('kot_addu', 'Kot Addu', 'D.G. Khan', 65, 14, 8, 8),
('lahore', 'Lahore', 'Lahore', 8200, 1200, 450, 650),
('layyah', 'Layyah', 'D.G. Khan', 80, 16, 8, 10),
('lodhran', 'Lodhran', 'Multan', 70, 14, 8, 10),
('mandi_bahauddin', 'Mandi Bahauddin', 'Gujranwala', 85, 18, 10, 12),
('mianwali', 'Mianwali', 'Sargodha', 95, 20, 10, 12),
('multan', 'Multan', 'Multan', 850, 160, 65, 100),
('murree', 'Murree', 'Rawalpindi', 130, 30, 15, 22),
('muzaffargarh', 'Muzaffargarh', 'D.G. Khan', 135, 28, 14, 18),
('nankana_sahib', 'Nankana Sahib', 'Lahore', 90, 20, 10, 12),
('narowal', 'Narowal', 'Gujranwala', 80, 18, 10, 10),
('okara', 'Okara', 'Sahiwal', 160, 32, 16, 20),
('pakpattan', 'Pakpattan', 'Sahiwal', 85, 18, 10, 10),
('rahim_yar_khan', 'Rahim Yar Khan', 'Bahawalpur', 240, 48, 22, 30),
('rajanpur', 'Rajanpur', 'D.G. Khan', 70, 15, 8, 10),
('rawalpindi', 'Rawalpindi', 'Rawalpindi', 1450, 260, 110, 180),
('sahiwal', 'Sahiwal', 'Sahiwal', 230, 45, 20, 30),
('sargodha', 'Sargodha', 'Sargodha', 320, 60, 28, 40),
('sheikhupura', 'Sheikhupura', 'Lahore', 260, 50, 24, 35),
('sialkot', 'Sialkot', 'Gujranwala', 420, 80, 36, 55),
('toba_tek_singh', 'Toba Tek Singh', 'Faisalabad', 95, 20, 10, 12),
('vehari', 'Vehari', 'Multan', 110, 22, 12, 15),
('wazirabad', 'Wazirabad', 'Gujranwala', 75, 16, 8, 10)
ON CONFLICT (id) DO NOTHING;

-- -----------------------------------------------------------------------------
-- 2. USERS & PROFILES TABLE (Aligned with Supabase Auth auth.users)
-- -----------------------------------------------------------------------------
CREATE TYPE user_role AS ENUM ('DISTRICT_USER', 'ADMIN', 'AUDITOR');

CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    nrtc_employee_id VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    role user_role NOT NULL DEFAULT 'DISTRICT_USER',
    district_id VARCHAR(50) REFERENCES public.districts(id),
    designation VARCHAR(150) DEFAULT 'NRTC Resident Site Engineer',
    contractor VARCHAR(150) DEFAULT 'National Radio & Telecommunication Corporation (NRTC)',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT chk_district_assigned CHECK (
        (role = 'DISTRICT_USER' AND district_id IS NOT NULL) OR
        (role IN ('ADMIN', 'AUDITOR'))
    )
);

-- -----------------------------------------------------------------------------
-- 3. DAILY REPORTS TABLE
-- -----------------------------------------------------------------------------
CREATE TYPE report_status AS ENUM ('DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'NEEDS_REVISION', 'REJECTED');

CREATE TABLE IF NOT EXISTS public.daily_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id),
    nrtc_employee_id VARCHAR(50) NOT NULL,
    contractor VARCHAR(100) NOT NULL DEFAULT 'NRTC',
    client_authority VARCHAR(100) NOT NULL DEFAULT 'Punjab Safe Cities Authority (PSCA)',
    district_id VARCHAR(50) NOT NULL REFERENCES public.districts(id),
    report_date DATE NOT NULL,
    status report_status NOT NULL DEFAULT 'SUBMITTED',
    submitted_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,

    -- Camera Counts & Health
    ipnv_installed INTEGER NOT NULL CHECK (ipnv_installed >= 0),
    ipnv_online INTEGER NOT NULL CHECK (ipnv_online >= 0 AND ipnv_online <= ipnv_installed),

    cee_installed INTEGER NOT NULL CHECK (cee_installed >= 0),
    cee_online INTEGER NOT NULL CHECK (cee_online >= 0 AND cee_online <= cee_installed),

    dee_installed INTEGER NOT NULL DEFAULT 0 CHECK (dee_installed >= 0),
    dee_online INTEGER NOT NULL DEFAULT 0 CHECK (dee_online >= 0 AND dee_online <= dee_installed),

    ps_installed INTEGER NOT NULL DEFAULT 0 CHECK (ps_installed >= 0),
    ps_online INTEGER NOT NULL DEFAULT 0 CHECK (ps_online >= 0 AND ps_online <= ps_installed),

    dc_installed INTEGER NOT NULL DEFAULT 0 CHECK (dc_installed >= 0),
    dc_online INTEGER NOT NULL DEFAULT 0 CHECK (dc_online >= 0 AND dc_online <= dc_installed),

    frnv_installed INTEGER NOT NULL DEFAULT 0 CHECK (frnv_installed >= 0),
    frnv_online INTEGER NOT NULL DEFAULT 0 CHECK (frnv_online >= 0 AND frnv_online <= frnv_installed),

    mcr_dr_installed INTEGER NOT NULL DEFAULT 0 CHECK (mcr_dr_installed >= 0),
    mcr_dr_online INTEGER NOT NULL DEFAULT 0 CHECK (mcr_dr_online >= 0 AND mcr_dr_online <= mcr_dr_installed),

    -- Auxiliary Systems
    wifi_installed INTEGER NOT NULL DEFAULT 0 CHECK (wifi_installed >= 0),
    wifi_online INTEGER NOT NULL DEFAULT 0 CHECK (wifi_online >= 0 AND wifi_online <= wifi_installed),

    panic_installed INTEGER NOT NULL DEFAULT 0 CHECK (panic_installed >= 0),
    panic_online INTEGER NOT NULL DEFAULT 0 CHECK (panic_online >= 0 AND panic_online <= panic_installed),

    environmental_installed INTEGER NOT NULL DEFAULT 0 CHECK (environmental_installed >= 0),
    environmental_online INTEGER NOT NULL DEFAULT 0 CHECK (environmental_online >= 0 AND environmental_online <= environmental_installed),

    biometric_installed INTEGER NOT NULL DEFAULT 0 CHECK (biometric_installed >= 0),
    biometric_online INTEGER NOT NULL DEFAULT 0 CHECK (biometric_online >= 0 AND biometric_online <= biometric_installed),

    -- Offline Reasons & Hardware Faults
    ipnv_offline_reason TEXT,
    cee_offline_reason TEXT,
    ps_offline_reason TEXT,
    dc_offline_reason TEXT,
    rma_details TEXT,

    -- Optical Fiber Cable (OFC) Cut Log
    ofc_cut VARCHAR(10) NOT NULL DEFAULT 'No' CHECK (ofc_cut IN ('Yes', 'No')),
    ofc_location TEXT,
    ofc_type VARCHAR(100),
    ofc_details TEXT,

    -- Generator & Power Outages
    generator_runtime NUMERIC(5, 2) NOT NULL DEFAULT 0.0 CHECK (generator_runtime >= 0),
    major_daily_activity TEXT NOT NULL,
    other_issues TEXT,
    attachments JSONB DEFAULT '[]'::jsonb,

    -- PMU Admin Audit & Approval Workflow
    admin_remarks TEXT,
    reviewed_by UUID REFERENCES public.profiles(id),
    reviewed_at TIMESTAMP WITH TIME ZONE,

    -- Unique constraint: Only one daily report per district per day
    CONSTRAINT uq_district_daily_report UNIQUE (district_id, report_date)
);

-- Indexes for lightning fast queries
CREATE INDEX IF NOT EXISTS idx_reports_district_date ON public.daily_reports(district_id, report_date DESC);
CREATE INDEX IF NOT EXISTS idx_reports_status ON public.daily_reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_date ON public.daily_reports(report_date DESC);

-- -----------------------------------------------------------------------------
-- 4. ROW-LEVEL SECURITY (RLS) POLICIES
-- -----------------------------------------------------------------------------
ALTER TABLE public.districts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_reports ENABLE ROW LEVEL SECURITY;

-- Districts: Read-only for all authenticated users
CREATE POLICY "Allow read districts for authenticated users"
ON public.districts FOR SELECT
TO authenticated
USING (true);

-- Profiles: Users can view profiles, only Admins can update roles
CREATE POLICY "Allow view profiles"
ON public.profiles FOR SELECT
TO authenticated
USING (true);

-- Daily Reports: STRICT DISTRICT LOCKING
-- Policy 1: District Users can only SELECT reports for their assigned district
CREATE POLICY "District users can only view their district reports"
ON public.daily_reports FOR SELECT
TO authenticated
USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('ADMIN', 'AUDITOR')
    OR
    district_id = (SELECT district_id FROM public.profiles WHERE id = auth.uid())
);

-- Policy 2: District Users can only INSERT reports for their assigned district
CREATE POLICY "District users can only insert for their district"
ON public.daily_reports FOR INSERT
TO authenticated
WITH CHECK (
    district_id = (SELECT district_id FROM public.profiles WHERE id = auth.uid())
    AND user_id = auth.uid()
);

-- Policy 3: District Users can only UPDATE their district's reports if status is not APPROVED
CREATE POLICY "District users can update unapproved reports"
ON public.daily_reports FOR UPDATE
TO authenticated
USING (
    (
        (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'DISTRICT_USER'
        AND district_id = (SELECT district_id FROM public.profiles WHERE id = auth.uid())
        AND status IN ('SUBMITTED', 'DRAFT', 'NEEDS_REVISION')
    )
    OR
    (
        (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('ADMIN', 'AUDITOR')
    )
);

-- Policy 4: Admins have full access to approve / remark on reports
CREATE POLICY "Admins have full update access"
ON public.daily_reports FOR UPDATE
TO authenticated
USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'ADMIN'
);

-- -----------------------------------------------------------------------------
-- 5. AUTOMATIC TIMESTAMP TRIGGER
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = TIMEZONE('utc'::text, NOW());
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER trg_update_daily_reports_timestamp
    BEFORE UPDATE ON public.daily_reports
    FOR EACH ROW
    EXECUTE PROCEDURE update_updated_at_column();

-- -----------------------------------------------------------------------------
-- 6. DISTRICT FIELD EMPLOYEES (2-3 PER DISTRICT)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.district_employees (
    id VARCHAR(50) PRIMARY KEY,
    employee_id VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    role_type VARCHAR(50) NOT NULL, -- 'SITE_LEAD', 'FIBER_CCTV_TECH', 'POWER_GEN_TECH'
    designation VARCHAR(150) NOT NULL,
    district_id VARCHAR(50) NOT NULL REFERENCES public.districts(id),
    phone VARCHAR(50),
    email VARCHAR(150),
    active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- -----------------------------------------------------------------------------
-- 7. LIVE GEOLOCATION ATTENDANCE LOGS
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.attendance_logs (
    id VARCHAR(100) PRIMARY KEY,
    employee_id VARCHAR(50) NOT NULL REFERENCES public.district_employees(employee_id),
    employee_name VARCHAR(150) NOT NULL,
    designation VARCHAR(150),
    district_id VARCHAR(50) NOT NULL REFERENCES public.districts(id),
    district_name VARCHAR(100) NOT NULL,
    date DATE NOT NULL,
    check_in_time TIME NOT NULL,
    check_out_time TIME,
    shift VARCHAR(50) NOT NULL DEFAULT 'MORNING_OM',
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    accuracy_meters DOUBLE PRECISION,
    distance_from_center_km DOUBLE PRECISION,
    is_within_geofence BOOLEAN NOT NULL DEFAULT true,
    status VARCHAR(50) NOT NULL DEFAULT 'PRESENT', -- 'PRESENT', 'ABSENT', 'OUT_OF_BOUNDS', 'LATE'
    remarks TEXT,
    verified_by VARCHAR(50) NOT NULL DEFAULT 'GEO_VERIFIED',
    reviewed_by VARCHAR(150),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE (employee_id, date)
);

-- -----------------------------------------------------------------------------
-- 8. DISTRICT OPERATIONAL FINANCIAL EXPENSES
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.district_expenses (
    id VARCHAR(100) PRIMARY KEY,
    district_id VARCHAR(50) NOT NULL REFERENCES public.districts(id),
    district_name VARCHAR(100) NOT NULL,
    user_id VARCHAR(100) NOT NULL,
    user_name VARCHAR(150) NOT NULL,
    expense_date DATE NOT NULL,
    category VARCHAR(50) NOT NULL, -- 'FUEL', 'FIBER_REPAIR', 'HARDWARE_SPARES', 'TRAVEL_TADA', 'POWER_UPS', 'FACILITY_AC', 'PETTY_CASH', 'EMERGENCY'
    title VARCHAR(255) NOT NULL,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
    payment_method VARCHAR(50) NOT NULL DEFAULT 'CASH',
    vendor_name VARCHAR(150) NOT NULL,
    invoice_number VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    receipt_attachment TEXT,
    status VARCHAR(50) NOT NULL DEFAULT 'PENDING_APPROVAL', -- 'PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'REIMBURSED'
    admin_remarks TEXT,
    reviewed_by VARCHAR(150),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

