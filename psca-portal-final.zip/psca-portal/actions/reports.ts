"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import type { ReportDraft, ReportStatus } from "@/lib/types";

/** Loads (or creates) today's/selected date's report for the signed-in district user's own district. */
export async function getMyReportForDate(reportDate: string) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: "Not authenticated" as const };

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();
  if (!profile) return { error: "Profile not found" as const };

  const { data: report } = await supabase
    .from("daily_reports")
    .select("*")
    .eq("district_id", profile.district_id)
    .eq("report_date", reportDate)
    .maybeSingle();

  return { profile, report };
}

/** Creates or updates (upsert on district_id + report_date) the signed-in user's daily report. */
export async function saveDailyReport(
  draft: ReportDraft,
  status: Extract<ReportStatus, "DRAFT" | "SUBMITTED">
) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: "Not authenticated." };

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  if (!profile || !profile.district_id) {
    return { error: "Aapki profile ke sath koi district assign nahi hai." };
  }

  const payload = {
    user_id: user.id,
    nrtc_employee_id: profile.nrtc_employee_id,
    contractor: profile.contractor ?? "NRTC",
    client_authority: "Punjab Safe Cities Authority (PSCA)",
    district_id: profile.district_id,
    status,
    ...draft,
    generator_runtime: Number(draft.generator_runtime) || 0,
    submitted_at: new Date().toISOString(),
  };

  const { data, error } = await supabase
    .from("daily_reports")
    .upsert(payload, { onConflict: "district_id,report_date" })
    .select()
    .single();

  if (error) {
    return { error: error.message };
  }

  revalidatePath("/dashboard");
  return { data };
}

/** Admin/PMU: filterable list across all districts. */
export async function listReports(filters: {
  districtId?: string;
  status?: ReportStatus;
  from?: string;
  to?: string;
  search?: string;
}) {
  const supabase = await createClient();
  let query = supabase
    .from("daily_reports")
    .select("*, districts(name, division), profiles(name, designation)")
    .order("report_date", { ascending: false });

  if (filters.districtId) query = query.eq("district_id", filters.districtId);
  if (filters.status) query = query.eq("status", filters.status);
  if (filters.from) query = query.gte("report_date", filters.from);
  if (filters.to) query = query.lte("report_date", filters.to);

  const { data, error } = await query;
  if (error) return { error: error.message, data: [] };

  let rows = data ?? [];
  if (filters.search) {
    const q = filters.search.toLowerCase();
    rows = rows.filter(
      (r: any) =>
        r.districts?.name?.toLowerCase().includes(q) ||
        r.profiles?.name?.toLowerCase().includes(q)
    );
  }

  return { data: rows };
}

/** Admin/PMU: approve, request revision, or reject a report with remarks. */
export async function reviewReport(
  reportId: string,
  status: Extract<ReportStatus, "APPROVED" | "NEEDS_REVISION" | "REJECTED">,
  remarks: string
) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: "Not authenticated." };

  const { error } = await supabase
    .from("daily_reports")
    .update({
      status,
      admin_remarks: remarks || null,
      reviewed_by: user.id,
      reviewed_at: new Date().toISOString(),
    })
    .eq("id", reportId);

  if (error) return { error: error.message };

  revalidatePath("/admin/reports");
  return { ok: true };
}

export async function getPunjabOverview() {
  const supabase = await createClient();
  const today = new Date().toISOString().slice(0, 10);

  const [{ data: districts }, { data: todayReports }, { data: allReports }] =
    await Promise.all([
      supabase.from("districts").select("id, name, division"),
      supabase
        .from("daily_reports")
        .select(
          "district_id, status, ofc_cut, ipnv_installed, ipnv_online, cee_installed, cee_online, dee_installed, dee_online, ps_installed, ps_online, dc_installed, dc_online, frnv_installed, frnv_online, mcr_dr_installed, mcr_dr_online"
        )
        .eq("report_date", today),
      supabase
        .from("daily_reports")
        .select(
          "district_id, ipnv_installed, ipnv_online, cee_installed, cee_online, dee_installed, dee_online, ps_installed, ps_online, dc_installed, dc_online, frnv_installed, frnv_online, mcr_dr_installed, mcr_dr_online, ofc_cut, report_date"
        )
        .order("report_date", { ascending: false })
        .limit(37 * 8),
    ]);

  return {
    districts: districts ?? [],
    todayReports: todayReports ?? [],
    recentReports: allReports ?? [],
  };
}
